--[[
	This ModuleScript is for whitelisting administrators for your game, to use Technica.
	You can add as many as you want, just put a , after each user.
	To remove an admin, just remove their entire name or line.
]]--


local Technica_Administrators = {
	"Luhkaaa", -- You can remove me from the list if you want to.
	"Millersons", -- You can remove me from the list if you want to.
	"Da_Fr0st", -- Another user right here, make sure it's like the example above. (You can delete this text, this is just for you to know how.)
	-- .. and so on
	-- ..
}

return Technica_Administrators