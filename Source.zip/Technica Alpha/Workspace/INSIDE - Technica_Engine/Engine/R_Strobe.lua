for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do spawn(function() while wait() do
			if v.Name == "Ta2" or v.Name == "Ta4" or v.Name == "Ta6" or v.Name == "Ta8" or v.Name == "Ta10" or v.Name == "Ta12" or v.Name == "Ta13" or v.Name == "Ta15" or v.Name == "Ta17" or v.Name == "Ta19" or v.Name == "Ta21" or v.Name == "Ta23" then
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(0) v.Head.Beam.SpotLight.Brightness = 10 v.Head.Lens.Transparency = 0
				wait()
				v.Head.Beam.light.Transparency = NumberSequence.new(1) v.Head.Beam.SpotLight.Brightness = 0	 v.Head.Lens.Transparency = 1
			end
		end
	end)
end