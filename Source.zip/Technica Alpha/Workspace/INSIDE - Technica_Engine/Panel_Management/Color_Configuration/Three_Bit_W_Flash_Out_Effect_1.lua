local preview1 = game.Workspace.TechnicaPannel:WaitForChild("MainPannel").P3.ColorPreviews.A
local preview2 = game.Workspace.TechnicaPannel:WaitForChild("MainPannel").P3.ColorPreviews.B
local preview3 = game.Workspace.TechnicaPannel:WaitForChild("MainPannel").P3.ColorPreviews.C

while true do
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta12" or v.Name == "Ta16" or v.Name == "Ta19" or v.Name == "Ta22" or v.Name == "Ta3" or v.Name == "Ta6" or v.Name == "Ta9" or v.Name == "Ta13" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview1.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview1.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview1.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta11" or v.Name == "Ta14" or v.Name == "Ta17" or v.Name == "Ta2" or v.Name == "Ta20" or v.Name == "Ta23" or v.Name == "Ta5" or v.Name == "Ta8" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview1.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview1.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview1.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta1" or v.Name == "Ta10" or v.Name == "Ta15" or v.Name == "Ta18" or v.Name == "Ta24" or v.Name == "Ta4" or v.Name == "Ta7" or v.Name == "Ta21" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview1.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview1.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview1.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta12" or v.Name == "Ta16" or v.Name == "Ta19" or v.Name == "Ta22" or v.Name == "Ta3" or v.Name == "Ta6" or v.Name == "Ta9" or v.Name == "Ta13" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview2.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview2.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview2.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta11" or v.Name == "Ta14" or v.Name == "Ta17" or v.Name == "Ta2" or v.Name == "Ta20" or v.Name == "Ta23" or v.Name == "Ta5" or v.Name == "Ta8" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview2.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview2.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview2.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
	for i,v in pairs (game:GetService("Workspace").TaLights:GetChildren()) do
		spawn(function()
			if v.Name == "Ta1" or v.Name == "Ta10" or v.Name == "Ta15" or v.Name == "Ta18" or v.Name == "Ta24" or v.Name == "Ta4" or v.Name == "Ta7" or v.Name == "Ta21" then
				v.Head.Beam.SpotLight.Color = Color3.fromRGB(255, 255, 255)
				v.Head.Beam.light.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255))
				wait(0.04)
				v.Head.Lens.Color = preview2.BackgroundColor3
				v.Head.Beam.SpotLight.Color = preview2.BackgroundColor3
				v.Head.Beam.light.Color = ColorSequence.new(preview2.BackgroundColor3)
			end
		end)
	end
	wait(_G.BPMColor)
end